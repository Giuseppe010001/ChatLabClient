/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatlabclient;

import java.io.PrintWriter; // Importare la classe PrintWriter
import java.io.IOException; // Importare la classe IOException
import java.net.Socket; // Importare la classe Socket
import java.net.UnknownHostException; // Importare la classe UnknownHostException
import static javax.swing.JOptionPane.showMessageDialog; // Importare il metodo statico showMessageDialog dalla classe JOptionPane
import static javax.swing.JOptionPane.ERROR_MESSAGE; // Importare la costante ERROR_MESSAGE dalla classe JOptionPane

/**
 *
 * @author 39327
 */
public class ChatClient extends Thread {
    
    // Dichiarazione attributi
    private final ClientFrame interfacciaGrafica;
    private final String host;
    private final int porta;

    // Metodi costruttori
    public ChatClient(ClientFrame interfacciaGrafica, String host, int porta) {
        this.interfacciaGrafica = interfacciaGrafica;
        this.host = host;
        this.porta = porta;
    }

    // Altri metodi
    // Per eseguire un thread
    @Override
    public void run() {
        
        // Dichiarazione variabili (locali)
        String messaggioClient = "";

        // Dichiarazione oggetti (locali)
        PrintWriter messaggioClientOut;
        ServerListener listener;

        // Verificare che la comunicazione client-server vada sempre a buon fine
        try(Socket socket = new Socket(host, porta)) {

            // Implementazione oggetti necessari allo scambio di informazioni (stream) client-server
            messaggioClientOut = new PrintWriter(socket.getOutputStream(), true);
            listener = new ServerListener(interfacciaGrafica, socket);
            listener.start();

            // Messaggio di conferma di connessione al server in ascolto su di una determinata porta
            interfacciaGrafica.setAreaOutputClient("Connesso al server " + host + " sulla porta " + porta + ".\n");
            
            // Messaggio di segnalazione riguardante la modalità da utilizzare per effettuare l'autenticazione
            interfacciaGrafica.getCampoInput().setToolTipText("NICK<TAB><Nickname>");

            // Autenticazione alla rete di comunicazione
            do {
                
                // Se è stato premuto il pulsante di invio
                if (interfacciaGrafica.isInviato()) {
                    
                    // Chiamare la procedura setInviato associata al frame interfacciaGrafica
                    interfacciaGrafica.setInviato();
                    
                    // Memorizzare il messaggio scritto in campoInput
                    messaggioClient = interfacciaGrafica.getCampoInput().getText();
                                                            
                    // Invio del messaggio
                    messaggioClientOut.println(messaggioClient);
                }
                
                // Attesa di listener
                join(10);
            } while (!messaggioClient.contains("NICK\t") || listener.getMessaggioServer().equals("App: Attenzione! Utente già esistente."));

            // Disattivare la possibilità di uscire dall'applicativo senza aver prima comunicato "QUIT"
            interfacciaGrafica.setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
            
            // Modalità di comunicazione
            interfacciaGrafica.setAreaOutputClient("""
                    \n\nModalità:
                    - CHAT: comunicazione con un particolare utente (inserirne il relativo nickname);
                    - BROADCAST: comunicazione con tutti gli utenti;
                    - NICK: modifica del proprio nickname;
                    - LIST: visualizzazione di tutti gli utenti connessi;
                    - QUIT: disconnessione.\n
                    """);
            
            // Messaggio di segnalazione per l'inserimento di un messaggio
            interfacciaGrafica.getCampoInput().setToolTipText("<Modalità>[<TAB>][<Nickname>][<TAB>][<Corpo>]");

            // Scambio di messaggi
            do {
                
                // Se è stato premuto il pulsante di invio
                if (interfacciaGrafica.isInviato()) {
                    
                    // Chiamare la procedura setInviato associata al frame interfacciaGrafica
                    interfacciaGrafica.setInviato();
                    
                    // Memorizzare il messaggio scritto in campoInput
                    messaggioClient = interfacciaGrafica.getCampoInput().getText();

                    // Invio del messaggio
                    messaggioClientOut.println(messaggioClient);
                    
                    // Attesa di listener
                    join(10);

                    // Comunicazione Unicast
                    if (messaggioClient.contains("CHAT\t") && !listener.getMessaggioServer().equals("App: Attenzione! Utente inesistente.") && !listener.getMessaggioServer().equals("App: Attenzione! Non è consentito comunicare con se stessi!")) {
                        
                        // Messaggio di segnalazione riguardante la modalità da utilizzare per effettuare l'autenticazione
                        interfacciaGrafica.getCampoInput().setToolTipText("[STOP][<Corpo>]");
                        
                        do {
                            
                            // Se è stato premuto il pulsante di invio
                            if (interfacciaGrafica.isInviato()) {
                                
                                // Chiamare la procedura setInviato associata al frame interfacciaGrafica
                                interfacciaGrafica.setInviato();
                                
                                // Memorizzare il messaggio scritto in campoInput
                                messaggioClient = interfacciaGrafica.getCampoInput().getText();
                                
                                // Invio del messaggio
                                messaggioClientOut.println(messaggioClient);
                            }
                            
                            // Attesa di listener
                            join(10);
                        } while (!messaggioClient.equals("STOP"));
                    }
                }
                
                // Attesa di listener
                join(10);
            } while (!messaggioClient.equals("QUIT"));

            // Disconnessione
            // Chiusura del socket di comunicazione
            socket.close();
            // Chiusura dello stream verso il server
            messaggioClientOut.close();
            // Chiudere il frame interfacciaGrafica
            interfacciaGrafica.dispose();
        } catch (UnknownHostException e) {

            // Visualizzare un pop up di errore (di host sconosciuto)
            showMessageDialog(null, "Host sconosciuto: " + host + '.', "Errore", ERROR_MESSAGE);
            
            // Chiudere il frame interfacciaGrafica
            interfacciaGrafica.dispose();
        } catch (IOException e) {

            // Visualizzare un pop up di errore (di I/O)
            showMessageDialog(null, "Errore di I/O con l'host " + host + '.', "Errore", ERROR_MESSAGE);
            
            // Chiudere il frame interfacciaGrafica
            interfacciaGrafica.dispose();
        } catch (InterruptedException e) {

            // Visualizzare un pop up di errore (di interruzione improvvisa)
            showMessageDialog(null, "Interruzione improvvisa.", "Errore", ERROR_MESSAGE);
            
            // Chiudere il frame interfacciaGrafica
            interfacciaGrafica.dispose();
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 *
 * Developed by Giuseppe Carlino
 */
package chatlabclient;

import java.awt.Color; // Importare la classe Color
import java.awt.Image; // Importare la classe Image
import javax.swing.ImageIcon; // Importare la classe ImageIcon
import javax.swing.JTextField; // Importare la classe JTextField

/**
 *
 * @author 39327
 */
public class ClientFrame extends javax.swing.JFrame {
    
    // Dichiarazione attributi
    private boolean isInviato;

    // Metodi costruttori
    public ClientFrame() {
        initComponents();
        isInviato = false;
        
        // Dichiarazione ed implementazione oggetti (locali)
        Image icona = new ImageIcon(this.getClass().getResource("ct.png")).getImage();
        
        // Settaggio dell'icona di frame
        this.setIconImage(icona);
        
        // Impostare il colore nero come colore di sfondo del frame
        getContentPane().setBackground(Color.BLACK);        
        
        // Visualizzare a video il frame
        setVisible(true);
    }
    
    // Metodi getter
    public boolean isInviato() {
        return isInviato;
    }
    public JTextField getCampoInput() {
        return campoInput;
    }
    
    // Metodi setter
    public void setInviato() {
        isInviato = false;
    }
    // Particolare metodo setter che aggiunge invece che sovrascrivere
    public void setAreaOutputClient(String nuovoContenuto) {
        
        // Dichiarazione ed implementazione variabili (locali)
        String vecchioContenuto = areaOutputClient.getText();
            
        // Aggiornare il contenuto dell'area di visualizzazione dell'output
        areaOutputClient.setText(vecchioContenuto + nuovoContenuto);
    }

    // Altri metodi
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        campoInput = new javax.swing.JTextField();
        bottoneInvio = new javax.swing.JButton();
        scorrimentoAreaOutputClient = new javax.swing.JScrollPane();
        areaOutputClient = new javax.swing.JTextArea();
        bottoneCancella = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ChatLabClient");
        setResizable(false);

        campoInput.setBackground(new java.awt.Color(0, 0, 0));
        campoInput.setFont(new java.awt.Font("Courier New", 1, 13)); // NOI18N
        campoInput.setForeground(new java.awt.Color(0, 255, 153));
        campoInput.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        campoInput.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        bottoneInvio.setBackground(new java.awt.Color(0, 0, 0));
        bottoneInvio.setFont(new java.awt.Font("Courier New", 1, 13)); // NOI18N
        bottoneInvio.setForeground(new java.awt.Color(0, 255, 153));
        bottoneInvio.setText("Invia");
        bottoneInvio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        bottoneInvio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bottoneInvio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottoneInvioActionPerformed(evt);
            }
        });

        areaOutputClient.setEditable(false);
        areaOutputClient.setBackground(new java.awt.Color(0, 0, 0));
        areaOutputClient.setColumns(20);
        areaOutputClient.setFont(new java.awt.Font("Courier New", 1, 13)); // NOI18N
        areaOutputClient.setForeground(new java.awt.Color(0, 255, 153));
        areaOutputClient.setRows(5);
        areaOutputClient.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        scorrimentoAreaOutputClient.setViewportView(areaOutputClient);

        bottoneCancella.setBackground(new java.awt.Color(0, 0, 0));
        bottoneCancella.setFont(new java.awt.Font("Courier New", 1, 13)); // NOI18N
        bottoneCancella.setForeground(new java.awt.Color(0, 255, 153));
        bottoneCancella.setText("Cancella");
        bottoneCancella.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        bottoneCancella.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bottoneCancella.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottoneCancellaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(campoInput, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(scorrimentoAreaOutputClient)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(bottoneInvio, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bottoneCancella, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(campoInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scorrimentoAreaOutputClient, javax.swing.GroupLayout.DEFAULT_SIZE, 367, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bottoneInvio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bottoneCancella, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    private void bottoneInvioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottoneInvioActionPerformed
        isInviato = true;
    }//GEN-LAST:event_bottoneInvioActionPerformed

    private void bottoneCancellaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottoneCancellaActionPerformed
        areaOutputClient.setText("L'output viene mostrato qui.");
    }//GEN-LAST:event_bottoneCancellaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        
        // Dichiarazione ed implementazione variabili
        String host = "192.168.153.1";
        int porta = 12345;

        // Dichiarazione ed implementazione oggetti
        ClientFrame interfacciaGrafica = new ClientFrame();
        ChatClient client = new ChatClient(interfacciaGrafica, host, porta);

        // Avvio del client istanziato
        client.start();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaOutputClient;
    private javax.swing.JButton bottoneCancella;
    private javax.swing.JButton bottoneInvio;
    private javax.swing.JTextField campoInput;
    private javax.swing.JScrollPane scorrimentoAreaOutputClient;
    // End of variables declaration//GEN-END:variables
}

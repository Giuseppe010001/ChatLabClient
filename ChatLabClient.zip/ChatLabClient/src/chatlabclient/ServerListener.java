/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatlabclient;

import java.io.BufferedReader; // Importare la classe BufferedReader
import java.io.InputStreamReader; // Importare la classe InputStreamReader
import java.io.IOException; // Importare la classe IOException
import java.net.Socket; // Importare la classe Socket
import static javax.swing.JOptionPane.showMessageDialog; // Importare il metodo statico showMessageDialog dalla classe JOptionPane
import static javax.swing.JOptionPane.ERROR_MESSAGE; // Importare la costante ERROR_MESSAGE dalla classe JOptionPane

/**
 *
 * @author 39327
 */
public class ServerListener extends Thread {
    
    // Dichiarazione attributi
    private final ClientFrame interfacciaGrafica;
    private final Socket socket;
    private String messaggioServer;

    // Metodi costruttori
    public ServerListener(ClientFrame interfacciaGrafica, Socket socket) {
        this.interfacciaGrafica = interfacciaGrafica;
        this.socket = socket;
        messaggioServer = "";
    }

    // Metodi getter
    public String getMessaggioServer() {
        return messaggioServer;
    }

    // Altri metodi
    // Per eseguire un thread
    @Override
    public void run() {
        try {

            // Dichiarazione ed implementazione oggetti (locali)
            BufferedReader messaggioServerIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // Avvio all'ascolto
            do {
                messaggioServer = messaggioServerIn.readLine();
                interfacciaGrafica.setAreaOutputClient('\n' + messaggioServer);
            } while (interfacciaGrafica.isActive());

            // Chiusura dello stream dal server
            messaggioServerIn.close();
        } catch (IOException e) {

            // Visualizzare un pop-up di errore (di I/O)
            showMessageDialog(null, "Errore di I/O con l'host " + socket.getInetAddress().getHostName() + '.', "Errore", ERROR_MESSAGE);
            
            // Chiudere il frame interfacciaGrafica
            interfacciaGrafica.dispose();
        }
    }
}
